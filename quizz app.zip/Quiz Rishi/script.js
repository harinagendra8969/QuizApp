        // Quiz Data (modified to remove images)
        const quizzes = {
            CyberSecurity: {
                title: "Cyber Security Quiz",
                description: "Test your cyber defense skills against digital threats!",
                icon: "fa-flask",
                questions: [
                    {
                        text: "What is the most common type of cyber attack?",
                options: [
                    { text: "DDoS", isCorrect: false },
                    { text: "Phishing", isCorrect: true },
                    { text: "SQL Injection", isCorrect: false },
                    { text: "Zero-day exploit", isCorrect: false }
                ],
            },
            {
                text: "What does HTTPS stand for?",
                options: [
                    { text: "HyperText Transfer Protocol Standard", isCorrect: false },
                    { text: "HyperText Transfer Protocol System", isCorrect: false },
                    { text: "HyperText Transfer Protocol Secure", isCorrect: true },
                    { text: "HyperText Transfer Protocol Service", isCorrect: false }
                ],
            },
            {
                text: "What is two-factor authentication used for?",
                options: [
                    { text: "Speeding up login process", isCorrect: false },
                    { text: "Adding an extra layer of security", isCorrect: true },
                    { text: "Reducing password complexity", isCorrect: false },
                    { text: "Bypassing security checks", isCorrect: false }
                ],
            },
            {
                text: "What type of malware encrypts files and demands payment?",
                options: [
                    { text: "Spyware", isCorrect: false },
                    { text: "Adware", isCorrect: false },
                    { text: "Ransomware", isCorrect: true },
                    { text: "Trojan", isCorrect: false }
                ],
            },
            {
                text: "What does VPN stand for?",
                options: [
                    { text: "Verified Private Network", isCorrect: false },
                    { text: "Virtual Public Network", isCorrect: false },
                    { text: "Verified Protected Network", isCorrect: false },
                    { text: "Virtual Private Network", isCorrect: true }
                ],
            },
            {
                text: "What is the purpose of a firewall?",
                options: [
                    { text: "To speed up internet connection", isCorrect: false },
                    { text: "To monitor and control network traffic", isCorrect: true },
                    { text: "To store passwords securely", isCorrect: false },
                    { text: "To prevent physical theft of devices", isCorrect: false }
                ],
            },
            {
                text: "What is a 'zero-day' vulnerability?",
                options: [
                    { text: "A bug that appears at midnight", isCorrect: false },
                    { text: "A security feature", isCorrect: false },
                    { text: "A flaw unknown to the vendor", isCorrect: true },
                    { text: "A type of encryption", isCorrect: false }
                ],
            },
            {
                text: "What should you do if you suspect a phishing email?",
                options: [
                    { text: "Reply to verify its authenticity", isCorrect: false },
                    { text: "Forward it to colleagues as a warning", isCorrect: false },
                    { text: "Click links to check where they lead", isCorrect: false },
                    { text: "Don't click links and report it", isCorrect: true }
                ],
                        },
            {
                text: "What is the strongest password practice?",
                options: [
                    { text: "Short, easy-to-remember words", isCorrect: false },
                    { text: "Using personal information", isCorrect: false },
                    { text: "Long, random phrases with special characters", isCorrect: true },
                    { text: "Same password for multiple accounts", isCorrect: false }
                ],
            },
            {
                text: "What does 'SSL' stand for in website security?",
                options: [
                    { text: "Super Secure Login", isCorrect: false },
                    { text: "System Security Layer", isCorrect: false },
                    { text: "Secure Sockets Layer", isCorrect: true },
                    { text: "Server Side Lock", isCorrect: false }
                ],
            }
                ]
            },
            WebDevelopment: {
                title: "Web Development Quiz",
                description: "Test your coding skills with this web dev quiz!",
                icon: "fa-landmark",
                questions: [
                    {
                        text: "What does HTML stand for?",
                options: [
                    { text: "HyperText Machine Language", isCorrect: false },
                    { text: "HyperText Markup Language", isCorrect: true },
                    { text: "HyperText Markdown Language", isCorrect: false },
                    { text: "HyperTool Markup Language", isCorrect: false }
                ],
            },
            {
                text: "Which language adds interactivity to websites?",
                options: [
                    { text: "JavaScript", isCorrect: true },
                    { text: "HTML", isCorrect: false },
                    { text: "CSS", isCorrect: false },
                    { text: "Python", isCorrect: false }
                ],
            },
            {
                text: "What does CSS stand for?",
                options: [
                    { text: "Computer Style Sheets", isCorrect: false },
                    { text: "Creative Style Sheets", isCorrect: false },
                    { text: "Cascading Style Sheets", isCorrect: true },
                    { text: "Colorful Style Sheets", isCorrect: false }
                ],
            },
            {
                text: "What is React primarily used for?",
                options: [
                    { text: "Building user interfaces", isCorrect: true },
                    { text: "Database management", isCorrect: false },
                    { text: "Server configuration", isCorrect: false },
                    { text: "Image editing", isCorrect: false }
                ],
            },
            {
                text: "What is the purpose of a API?",
                options: [
                    { text: "To store website content", isCorrect: false },
                    { text: "To design user interfaces", isCorrect: false },
                    { text: "To replace databases", isCorrect: false },
                    { text: "To enable communication between software components", isCorrect: true }
                ],
            },
            {
                text: "Which of these is a backend language?",
                options: [
                    { text: "Node.js", isCorrect: true },
                    { text: "HTML", isCorrect: false },
                    { text: "CSS", isCorrect: false },
                    { text: "React", isCorrect: false }
                ],
            },
            {
                text: "What does 'responsive design' mean?",
                options: [
                    { text: "Fast-loading websites", isCorrect: false },
                    { text: "Websites with many interactive elements", isCorrect: false },
                    { text: "Websites that adapt to different screen sizes", isCorrect: true },
                    { text: "Websites that respond quickly to user input", isCorrect: false }
                ],
            },
            {
                text: "What is version control primarily used for?",
                options: [
                    { text: "Tracking and managing code changes", isCorrect: true },
                    { text: "Controlling website visitors", isCorrect: false },
                    { text: "Managing server versions", isCorrect: false },
                    { text: "Controlling software licenses", isCorrect: false }
                ],
            },
            {
                text: "Which tag creates a hyperlink in HTML?",
                options: [
                    { text: "link", isCorrect: false },
                    { text: "a", isCorrect: true },
                    { text: "href", isCorrect: false },
                    { text: "url", isCorrect: false }
                ],
            },
            {
                text: "What does 'DOM' stand for in web development?",
                options: [
                    { text: "Data Object Management", isCorrect: false },
                    { text: "Digital Output Module", isCorrect: false },
                    { text: "Document Object Model", isCorrect: true },
                    { text: "Display Orientation Mode", isCorrect: false }
                ],
            }
                ]
            },
            Generalknowledge: {
                title: "General Knowledge Quiz",
                description: "Test your world knowledge in just 10 questions!",
                icon: "fa-globe-americas",
                questions: [
                    {
                        text: "What is the capital of France?",
                options: [
                    { text: "London", isCorrect: false },
                    { text: "Berlin", isCorrect: false },
                    { text: "Madrid", isCorrect: false },
                    { text: "Paris", isCorrect: true }
                ],
            },
            {
                text: "Which planet is closest to the sun?",
                options: [
                    { text: "Venus", isCorrect: false },
                    { text: "Earth", isCorrect: false },
                    { text: "Mercury", isCorrect: true },
                    { text: "Mars", isCorrect: false }
                ],
            },
            {
                text: "Who painted the Mona Lisa?",
                options: [
                    { text: "Pablo Picasso", isCorrect: false },
                    { text: "Leonardo da Vinci", isCorrect: true },
                    { text: "Vincent van Gogh", isCorrect: false },
                    { text: "Michelangelo", isCorrect: false }
                ],
            },
            {
                text: "What is the largest ocean on Earth?",
                options: [
                    { text: "Pacific", isCorrect: true },
                    { text: "Atlantic", isCorrect: false },
                    { text: "Indian", isCorrect: false },
                    { text: "Arctic", isCorrect: false }
                ],
            },
            {
                text: "Which country gifted the Statue of Liberty to the US?",
                options: [
                    { text: "England", isCorrect: false },
                    { text: "Canada", isCorrect: false },
                    { text: "Germany", isCorrect: false },
                    { text: "France", isCorrect: true }
                ],
            },
            {
                text: "How many continents are there?",
                options: [
                    { text: "5", isCorrect: false },
                    { text: "7", isCorrect: true },
                    { text: "6", isCorrect: false },
                    { text: "8", isCorrect: false }
                ],
            },
            {
                text: "What is the largest mammal?",
                options: [
                    { text: "Blue whale", isCorrect: true },
                    { text: "Elephant", isCorrect: false },
                    { text: "Giraffe", isCorrect: false },
                    { text: "Polar bear", isCorrect: false }
                ],
            },
            {
                text: "Which language has the most native speakers?",
                options: [
                    { text: "Spanish", isCorrect: false },
                    { text: "Mandarin Chinese", isCorrect: true },
                    { text: "English", isCorrect: false },
                    { text: "Hindi", isCorrect: false }
                ],
            },
            {
                text: "What is the currency of Japan?",
                options: [
                    { text: "Yen", isCorrect: true },
                    { text: "Won", isCorrect: false },
                    { text: "Yuan", isCorrect: false },
                    { text: "Ringgit", isCorrect: false }
                ],
            },
            {
                text: "Which planet is known as the Red Planet?",
                options: [
                    { text: "Jupiter", isCorrect: false },
                    { text: "Saturn", isCorrect: false },
                    { text: "Mars", isCorrect: true },
                    { text: "Venus", isCorrect: false }
                ],
            }
                ]
            }
        };

        // DOM Elements
        const startPage = document.getElementById('startPage');
        const quizContainer = document.getElementById('quizContainer');
        const resultsContainer = document.getElementById('resultsContainer');
        const startBtn = document.getElementById('startBtn');
        const startBtnText = document.getElementById('startBtnText');
        const quizTitle = document.getElementById('quizTitle');
        const questionCount = document.getElementById('questionCount');
        const progressBar = document.getElementById('progressBar');
        const questionText = document.getElementById('questionText');
        const optionsContainer = document.getElementById('optionsContainer');
        const nextBtn = document.getElementById('nextBtn');
        const quitBtn = document.getElementById('quitBtn');
        const finalScore = document.getElementById('finalScore');
        const scoreCircle = document.getElementById('scoreCircle');
        const correctAnswers = document.getElementById('correctAnswers');
        const totalQuestions = document.getElementById('totalQuestions');
        const timeTaken = document.getElementById('timeTaken');
        const accuracy = document.getElementById('accuracy');
        const resultMessage = document.getElementById('resultMessage');
        const restartBtn = document.getElementById('restartBtn');
        const quizCards = document.querySelectorAll('.quiz-card');
        const timer = document.getElementById('timer');
        const timeDisplay = document.getElementById('time');
        const themeToggle = document.getElementById('themeToggle');

        // Quiz Variables
        let currentQuiz = null;
        let currentQuestionIndex = 0;
        let score = 0;
        let selectedOption = null;
        let quizStartTime = 0;
        let timerInterval = null;
        let answeredQuestions = [];
        let darkMode = true;

        // Event Listeners
        quizCards.forEach(card => {
            card.addEventListener('click', () => {
                // Remove active class from all cards
                quizCards.forEach(c => c.classList.remove('active'));
                // Add active class to clicked card
                card.classList.add('active');
                // Set current quiz
                currentQuiz = card.getAttribute('data-quiz');
                // Update start button text
                startBtnText.textContent = `Start ${quizzes[currentQuiz].title}`;
            });
        });

        startBtn.addEventListener('click', startQuiz);
        nextBtn.addEventListener('click', nextQuestion);
        quitBtn.addEventListener('click', quitQuiz);
        restartBtn.addEventListener('click', restartQuiz);
        themeToggle.addEventListener('change', toggleTheme);

        // Functions
        function startQuiz() {
            if (!currentQuiz) {
                showToast('Please select a quiz first!');
                return;
            }

            // Hide start page, show quiz container
            startPage.style.display = 'none';
            quizContainer.style.display = 'block';
            resultsContainer.style.display = 'none';

            // Set quiz title
            quizTitle.textContent = quizzes[currentQuiz].title;

            // Reset quiz variables
            currentQuestionIndex = 0;
            score = 0;
            answeredQuestions = [];
            quizStartTime = Date.now();
            
            // Start timer
            startTimer();

            // Load first question
            loadQuestion();
        }

        function loadQuestion() {
            const question = quizzes[currentQuiz].questions[currentQuestionIndex];
            
            // Update question count
            questionCount.textContent = `Question ${currentQuestionIndex + 1} of ${quizzes[currentQuiz].questions.length}`;
            
            // Update progress bar
            progressBar.style.width = `${(currentQuestionIndex / quizzes[currentQuiz].questions.length) * 100}%`;
            
            // Set question text
            questionText.textContent = question.text;
            
            // Clear previous options
            optionsContainer.innerHTML = '';
            
            // Create new options
            question.options.forEach((option, index) => {
                const optionElement = document.createElement('div');
                optionElement.classList.add('option');
                
                const inputId = `option${currentQuestionIndex}_${index}`;
                
                optionElement.innerHTML = `
                    <input type="radio" name="option" id="${inputId}" value="${index}">
                    <label for="${inputId}" class="option-label">${option.text}</label>
                `;
                
                optionElement.addEventListener('click', () => selectOption(optionElement, index));
                optionsContainer.appendChild(optionElement);
            });
            
            // Reset next button
            nextBtn.disabled = true;
            selectedOption = null;
        }

        function selectOption(optionElement, optionIndex) {
            // If already answered, ignore new selections
            if (answeredQuestions[currentQuestionIndex]) return;
            
            // Remove selected class from all options
            document.querySelectorAll('.option').forEach(opt => {
                opt.classList.remove('selected');
                opt.querySelector('input').checked = false;
            });
            
            // Add selected class to clicked option
            optionElement.classList.add('selected');
            optionElement.querySelector('input').checked = true;
            
            // Enable next button
            nextBtn.disabled = false;
            selectedOption = optionIndex;
        }

        function nextQuestion() {
            if (selectedOption === null) return;
            
            // Get current question
            const question = quizzes[currentQuiz].questions[currentQuestionIndex];
            
            // Check if answer is correct
            const isCorrect = question.options[selectedOption].isCorrect;
            
            // Store answered question
            answeredQuestions[currentQuestionIndex] = {
                selectedOption,
                isCorrect,
                question: question.text,
                correctAnswer: question.options.find(opt => opt.isCorrect).text,
                explanation: question.explanation
            };
            
            // Add visual feedback
            const options = document.querySelectorAll('.option');
            options.forEach((option, index) => {
                if (question.options[index].isCorrect) {
                    option.classList.add('correct');
                } else if (index === selectedOption && !isCorrect) {
                    option.classList.add('incorrect');
                }
                option.style.pointerEvents = 'none';
            });
            
            // Update score if correct
            if (isCorrect) {
                score++;
            }
            
            // Move to next question or show results
            setTimeout(() => {
                currentQuestionIndex++;
                
                if (currentQuestionIndex < quizzes[currentQuiz].questions.length) {
                    loadQuestion();
                } else {
                    showResults();
                }
            }, 1000);
        }

        function showResults() {
            // Stop timer
            stopTimer();
            
            // Calculate time taken
            const timeElapsed = Date.now() - quizStartTime;
            const minutes = Math.floor(timeElapsed / 60000);
            const seconds = Math.floor((timeElapsed % 60000) / 1000);
            const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            
            // Calculate score percentage
            const totalQuestions = quizzes[currentQuiz].questions.length;
            const percentage = Math.round((score / totalQuestions) * 100);
            
            // Set final score and animate circle
            finalScore.textContent = score;
            document.getElementById('correctAnswers').textContent = score;
            document.getElementById('totalQuestions').textContent = totalQuestions;
            document.getElementById('timeTaken').textContent = formattedTime;
            document.getElementById('accuracy').textContent = `${percentage}%`;
            
            // Animate score circle
            const circumference = 565.48; // 2 * π * r (where r = 90)
            const offset = circumference - (percentage / 100) * circumference;
            scoreCircle.style.strokeDashoffset = offset;
            
            // Set result message based on percentage
            let message = "";
            let emoji = "";
            
            if (percentage >= 90) {
                message = "Outstanding! You're a true expert!";
                emoji = "🏆";
                createConfetti();
            } else if (percentage >= 75) {
                message = "Excellent work! You know your stuff!";
                emoji = "🎯";
            } else if (percentage >= 50) {
                message = "Good job! You've got a solid foundation!";
                emoji = "👍";
            } else {
                message = "Keep practicing! You'll get better!";
                emoji = "📚";
            }
            
            resultMessage.textContent = `${emoji} ${message} ${emoji}`;
            
            // Hide quiz container, show results container
            quizContainer.style.display = 'none';
            resultsContainer.style.display = 'block';
        }

        function quitQuiz() {
             if (confirm('Are you sure you want to quit the quiz? Your progress will be lost.')) {
                stopTimer();
                restartQuiz();
            }
        }

        function restartQuiz() {
            // Show start page, hide results container
            startPage.style.display = 'flex';
            resultsContainer.style.display = 'none';
            
            // Reset quiz selection
            quizCards.forEach(c => c.classList.remove('active'));
            currentQuiz = null;
            startBtnText.textContent = 'Start Quiz';
        }

        function startTimer() {
            quizStartTime = Date.now();
            timerInterval = setInterval(updateTimer, 1000);
        }

        function updateTimer() {
            const elapsed = Date.now() - quizStartTime;
            const minutes = Math.floor(elapsed / 60000);
            const seconds = Math.floor((elapsed % 60000) / 1000);
            timeDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }

        function stopTimer() {
            clearInterval(timerInterval);
        }
        function toggleTheme() {
            darkMode = !darkMode;
            
            if (darkMode) {
                document.body.style.background = 'linear-gradient(135deg, #1a1a2e, #16213e)';
                document.body.style.color = '#f8f9fa';
            } else {
                document.body.style.background = 'linear-gradient(135deg, #f8f9fa, #e9ecef)';
                document.body.style.color = '#212529';
            }
        }
        // Initialize
        document.addEventListener('DOMContentLoaded', () => {
            // Set initial theme based on preference
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            if (!prefersDark) {
                themeToggle.checked = true;
                toggleTheme();
            }
        });
